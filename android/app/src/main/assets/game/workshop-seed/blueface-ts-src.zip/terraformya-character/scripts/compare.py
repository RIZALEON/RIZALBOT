"""Side-by-side: reference frame f_01 vs code-drawn idle render. Needs Pillow.
Usage: python scripts/compare.py [ref_jpg] (default /workspace/character/frames/f_01.jpg)"""
import sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parent.parent
ref_path = sys.argv[1] if len(sys.argv) > 1 else '/workspace/character/frames/f_01.jpg'
ref = Image.open(ref_path).convert('RGB')
ref = ref.crop((int(ref.width * 0.146), 0, int(ref.width * 0.729), ref.height))
mine = Image.open(root / 'shots/idle-clean.png').convert('RGB').crop((330, 110, 910, 690))
H = 640
fit = lambda im: im.resize((round(im.width * H / im.height), H), Image.LANCZOS)
a, b = fit(ref), fit(mine)
c = Image.new('RGB', (a.width + b.width + 30, H + 60), (30, 29, 30))
c.paste(a, (10, 50)); c.paste(b, (a.width + 20, 50))
d = ImageDraw.Draw(c)
try:
    f = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 24)
except OSError:
    f = ImageFont.load_default()
d.text((20, 12), 'Reference f_01 (clay video)', fill=(241, 208, 154), font=f)
d.text((a.width + 30, 12), 'Code-drawn Phaser 4 idle', fill=(241, 208, 154), font=f)
c.save(root / 'shots/compare.png')
print('wrote shots/compare.png', c.size)
