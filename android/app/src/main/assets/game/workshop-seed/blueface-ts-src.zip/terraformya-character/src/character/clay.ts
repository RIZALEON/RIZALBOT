import Phaser from 'phaser';

/**
 * Tiny procedural "clay" drawing kit.
 * Every part of BLUEFACE is painted in code onto a Phaser CanvasTexture
 * (scene.textures.createCanvas) with the Canvas2D API: soft radial shading,
 * fingerprint speckles and a darker rim, so it looks like hand-modelled clay.
 * No image files are loaded anywhere.
 */

/** Texture supersampling so the character stays crisp on retina / FIT upscaling. */
export const RES = 2;

export interface Tone {
  base: string;
  lo: string;
  hi: string;
}

export interface TexInfo {
  /** texture key (the shared atlas) */
  key: string;
  /** frame name inside the atlas */
  frame: string;
  /** origin (0..1) that maps to the part's pivot */
  ox: number;
  oy: number;
}

export type Ctx = CanvasRenderingContext2D;

/** Deterministic RNG (mulberry32) so the clay texture is identical every run. */
export function rng(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function rgba(hex: string, a: number): string {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r},${g},${b},${a})`;
}

export function mix(h1: string, h2: string, t: number): string {
  const a = hexToRgb(h1);
  const b = hexToRgb(h2);
  const c = a.map((v, i) => Math.round(v + (b[i] - v) * t));
  return '#' + c.map((v) => v.toString(16).padStart(2, '0')).join('');
}

export function hexNum(hex: string): number {
  return parseInt(hex.replace('#', ''), 16);
}

/**
 * All parts are painted into ONE shared canvas atlas (single GPU texture, one
 * batch, fewer driver quirks). Simple shelf packing.
 */
export class Atlas {
  readonly key: string;
  readonly tex: Phaser.Textures.CanvasTexture;
  private cx = 2;
  private cy = 2;
  private rowH = 0;
  private size: number;

  constructor(scene: Phaser.Scene, key: string, size = 2048) {
    this.key = key;
    this.size = size;
    const existing = scene.textures.exists(key);
    if (existing) scene.textures.remove(key);
    const tex = scene.textures.createCanvas(key, size, size);
    if (!tex) throw new Error('could not create atlas');
    this.tex = tex;
  }

  /** Paint a w x h (local units) part whose pivot sits at (px, py); draw() works with the pivot at 0,0. */
  add(frame: string, w: number, h: number, px: number, py: number, draw: (ctx: Ctx) => void): TexInfo {
    const pw = Math.ceil(w * RES);
    const ph = Math.ceil(h * RES);
    if (this.cx + pw > this.size) { this.cx = 2; this.cy += this.rowH + 4; this.rowH = 0; }
    if (this.cy + ph > this.size) throw new Error('atlas full');
    const x = this.cx;
    const y = this.cy;
    this.cx += pw + 4;
    this.rowH = Math.max(this.rowH, ph);
    const ctx = this.tex.getContext();
    ctx.save();
    ctx.beginPath(); ctx.rect(x, y, pw, ph); ctx.clip();
    ctx.translate(x, y);
    ctx.scale(RES, RES);
    ctx.translate(px, py);
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    draw(ctx);
    ctx.restore();
    this.tex.add(frame, 0, x, y, pw, ph);
    return { key: this.key, frame, ox: px / w, oy: py / h };
  }

  done(): void { this.tex.refresh(); }
}

export interface ClayOpts {
  /** bounding box of the shape, used for gradients and speckles */
  box: [number, number, number, number];
  /** light position as fraction of the box (default upper-left) */
  light?: [number, number];
  speckle?: number; // density multiplier
  seed?: number;
  rim?: number; // rim line width
  rimColor?: string;
  shadowBlur?: number; // soft contact shadow under the part
  hiAlpha?: number;
  loAlpha?: number;
}

/** Fill a path with clay-style soft shading. `path` must only build the path. */
export function clay(ctx: Ctx, path: (c: Ctx) => void, tone: Tone, o: ClayOpts): void {
  const [x, y, w, h] = o.box;
  const [lx, ly] = o.light ?? [0.3, 0.22];
  const r = rng(o.seed ?? 7);

  // soft drop shadow so overlapping clay parts separate
  ctx.save();
  if (o.shadowBlur !== 0) {
    ctx.shadowColor = 'rgba(0,0,0,0.38)';
    ctx.shadowBlur = o.shadowBlur ?? 5;
    ctx.shadowOffsetX = 1.2;
    ctx.shadowOffsetY = 2.2;
  }
  ctx.beginPath();
  path(ctx);
  ctx.fillStyle = tone.base;
  ctx.fill();
  ctx.restore();

  ctx.save();
  ctx.beginPath();
  path(ctx);
  ctx.clip();

  // core shadow (lower-right)
  const g1 = ctx.createRadialGradient(
    x + w * (1 - lx * 0.6), y + h * (1 - ly * 0.4), 0,
    x + w * (1 - lx * 0.6), y + h * (1 - ly * 0.4), Math.max(w, h) * 0.95,
  );
  g1.addColorStop(0, rgba(tone.lo, o.loAlpha ?? 0.85));
  g1.addColorStop(1, rgba(tone.lo, 0));
  ctx.fillStyle = g1;
  ctx.fillRect(x - 4, y - 4, w + 8, h + 8);

  // key light (upper-left)
  const g2 = ctx.createRadialGradient(
    x + w * lx, y + h * ly, 0,
    x + w * lx, y + h * ly, Math.max(w, h) * 0.62,
  );
  g2.addColorStop(0, rgba(tone.hi, o.hiAlpha ?? 0.9));
  g2.addColorStop(0.45, rgba(tone.hi, (o.hiAlpha ?? 0.9) * 0.35));
  g2.addColorStop(1, rgba(tone.hi, 0));
  ctx.fillStyle = g2;
  ctx.fillRect(x - 4, y - 4, w + 8, h + 8);

  // fingerprint speckles / clay pores
  const n = Math.round(w * h * 0.03 * (o.speckle ?? 1));
  for (let i = 0; i < n; i++) {
    const sx = x + r() * w;
    const sy = y + r() * h;
    const rad = 0.35 + r() * 0.9;
    ctx.fillStyle = r() < 0.5 ? rgba(tone.lo, 0.22) : rgba(tone.hi, 0.18);
    ctx.beginPath();
    ctx.arc(sx, sy, rad, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  // rim
  if ((o.rim ?? 1.4) > 0) {
    ctx.save();
    ctx.beginPath();
    path(ctx);
    ctx.strokeStyle = o.rimColor ?? rgba(mix(tone.lo, '#000000', 0.45), 0.85);
    ctx.lineWidth = o.rim ?? 1.4;
    ctx.stroke();
    ctx.restore();
  }
}

/** Soft blob highlight / shadow spot. */
export function spot(ctx: Ctx, x: number, y: number, rx: number, ry: number, color: string, a: number): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(1, ry / rx);
  const g = ctx.createRadialGradient(0, 0, 0, 0, 0, rx);
  g.addColorStop(0, rgba(color, a));
  g.addColorStop(1, rgba(color, 0));
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, rx, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/** Run `fn` clipped to `path`. */
export function clipped(ctx: Ctx, path: (c: Ctx) => void, fn: () => void): void {
  ctx.save();
  ctx.beginPath();
  path(ctx);
  ctx.clip();
  fn();
  ctx.restore();
}

/** Diamond quilting (tunic / sleeves), drawn clipped by the caller. */
export function quilt(ctx: Ctx, box: [number, number, number, number], step: number, lo: string, hi: string): void {
  const [x, y, w, h] = box;
  ctx.lineWidth = 1;
  for (let d = -h; d < w + h; d += step) {
    ctx.strokeStyle = rgba(lo, 0.7);
    ctx.beginPath();
    ctx.moveTo(x + d, y);
    ctx.lineTo(x + d + h, y + h);
    ctx.moveTo(x + d + h, y);
    ctx.lineTo(x + d, y + h);
    ctx.stroke();
    ctx.strokeStyle = rgba(hi, 0.22);
    ctx.beginPath();
    ctx.moveTo(x + d + 1.2, y);
    ctx.lineTo(x + d + h + 1.2, y + h);
    ctx.stroke();
  }
  // tiny puff highlight in each diamond
  for (let yy = y; yy < y + h; yy += step / 2) {
    const off = Math.round((yy - y) / (step / 2)) % 2 ? step / 2 : 0;
    for (let xx = x + off; xx < x + w; xx += step) {
      spot(ctx, xx - 1, yy - 1, step * 0.28, step * 0.2, hi, 0.28);
    }
  }
}

/** Overlapping scale pattern (helmet / trousers). */
export function scales(
  ctx: Ctx,
  box: [number, number, number, number],
  sw: number,
  sh: number,
  lo: string,
  hi: string,
  seed: number,
  alpha = 1,
): void {
  const [x, y, w, h] = box;
  const r = rng(seed);
  let row = 0;
  for (let yy = y; yy < y + h + sh; yy += sh) {
    const off = row % 2 ? sw / 2 : 0;
    for (let xx = x - sw + off; xx < x + w + sw; xx += sw) {
      const j = (r() - 0.5) * 1.2;
      ctx.beginPath();
      ctx.arc(xx + j, yy, sw * 0.52, 0.1 * Math.PI, 0.9 * Math.PI);
      ctx.strokeStyle = rgba(lo, 0.75 * alpha);
      ctx.lineWidth = 1.3;
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(xx + j, yy - 1.2, sw * 0.45, 0.2 * Math.PI, 0.8 * Math.PI);
      ctx.strokeStyle = rgba(hi, 0.35 * alpha);
      ctx.lineWidth = 0.9;
      ctx.stroke();
    }
    row++;
  }
}
