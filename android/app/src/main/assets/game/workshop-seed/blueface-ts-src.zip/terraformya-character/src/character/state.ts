/** Serializable snapshot of BLUEFACE for the clay save. Keep it small and JSON-safe. */
export type BluefaceFacing = 'left' | 'right';
export type BluefaceAction = 'idle' | 'walk' | 'dig' | 'cheer' | 'takeThat';
export type BluefaceTool = 'axe-spade' | 'double-spade';

export interface BluefaceState {
  v: 1;
  name: 'BLUEFACE';
  crown: 'Я';
  position: { x: number; y: number };
  facing: BluefaceFacing;
  action: BluefaceAction;
  tool: BluefaceTool;
}

export function isBluefaceState(o: unknown): o is BluefaceState {
  const s = o as BluefaceState;
  return !!s && s.name === 'BLUEFACE' && s.crown === 'Я' && typeof s.position?.x === 'number' &&
    (s.facing === 'left' || s.facing === 'right');
}
