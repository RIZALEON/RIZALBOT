/**
 * BLUEFACE palette.
 * Hex values sampled with Python/PIL (median / 10th / 90th percentile of small
 * patches) from the reference frames of ref.mp4 (mostly f_01), then nudged a
 * little so they read at game size. base = mid tone, lo = shadow, hi = light.
 */
export const PALETTE = {
  bgTop: '#2f2d2e', // studio backdrop, upper
  bgMid: '#413f40', // sampled bg behind figure
  bgFloor: '#4c4a4b', // sampled floor near boots

  face: { base: '#1f4aa0', lo: '#0f2c66', hi: '#4a7ed1' }, // cobalt skin (#194396 / #3064af / #153975)
  ear: { base: '#73418c', lo: '#3c2049', hi: '#9a6ab5', inner: '#4d2250' }, // violet ears
  horn: { base: '#a93b3b', lo: '#732420', hi: '#c96a5f' }, // red horns
  helmet: { base: '#a47843', lo: '#5e3818', hi: '#deae86' }, // bronze scale helmet (#96743b / #bf9063)
  brow: { base: '#b0703f', lo: '#7e4421', hi: '#d69468' }, // orange-brown brows
  eyeWhite: '#f1ede4',
  pupil: '#1b1412',
  teeth: { base: '#efe8d6', lo: '#b7ab93' },
  mouth: { inside: '#3a0d14', tongue: '#b84656', lip: '#12306a' },

  jacket: { base: '#1c3666', lo: '#0c1f3f', hi: '#536397' }, // quilted tunic (#1c3666 / #162647 / #536397)
  collarRed: '#9a2f36', // red collar trim
  gold: { base: '#c79a5c', lo: '#6e4a22', hi: '#f1d09a' }, // buttons, piping, medallion (#d5ba90 / #926842)
  epaulette: { base: '#b8894f', lo: '#5a3510', hi: '#f1c79f' }, // gold fringe (#8c6442 / #f1c79f)
  gem: { base: '#3f9a4a', hi: '#a6f0a0', lo: '#1c4d22' }, // small green gems
  cuff: { base: '#7d333e', lo: '#561c20', hi: '#9a4d57' }, // maroon cuffs (#7d333e / #8e434d)
  hand: { base: '#5f8546', lo: '#354a2a', hi: '#86a06e' }, // green hands (#55833b / #70855e)
  belt: { base: '#5a3524', lo: '#2b1712', hi: '#8a5a40' },
  beltRed: '#b3302f', // red emblem on belt
  pants: { base: '#8a8580', lo: '#5e534f', hi: '#aaa29c' }, // gray woven trousers (#8a8985 / #8b7f79)
  boot: { base: '#755038', lo: '#422519', hi: '#9a6e52' }, // brown boots (#755038 / #744d3a)
  lace: '#c9b48a',

  wood: { base: '#7f5a48', lo: '#3a2418', hi: '#a37a60' }, // shaft (#7f5a48)
  steel: { base: '#8f9293', lo: '#5e5f60', hi: '#c9c6c3' }, // damascus axe (#8f9293 / #b4afac)
  // iridescent spade: gold -> pink -> purple sheen (#bca188 -> #d8a8a3 -> #937985)
  iri: ['#e7cf9a', '#d8a8a3', '#bca188', '#a58bb8', '#937985', '#e9c0c8'],
} as const;
