import Phaser from 'phaser';
import { Blueface } from './character/Blueface';
import type { BluefaceState } from './character/state';
import { TouchButton } from './ui/TouchButton';

const W = 1280;
const H = 720;
const GROUND = 640;

class DemoScene extends Phaser.Scene {
  hero!: Blueface;
  private keys!: Record<'left' | 'right' | 'a' | 'd' | 'space' | 'c' | 't', Phaser.Input.Keyboard.Key>;
  private touchDir = 0;

  constructor() { super('demo'); }

  create() {
    this.makeBackdrop();

    this.hero = new Blueface(this, W / 2, GROUND, 0.92);
    this.hero.setDepth(10);
    this.hero.on('dig', (p: { x: number; y: number }) => this.spawnMound(p.x, p.y));

    this.add.text(24, 20, 'BLUEFACE · TeraformЯ', {
      fontFamily: '"Arial Black", Arial, sans-serif', fontSize: '26px', color: '#f1d09a', resolution: 2,
    }).setShadow(2, 3, '#000', 4).setDepth(20);
    this.add.text(W - 24, 24, '←/→ or A/D walk · Space dig · C cheer · T take that', {
      fontFamily: 'Arial, sans-serif', fontSize: '17px', color: '#b8b2aa', resolution: 2,
    }).setOrigin(1, 0).setDepth(20);

    const kb = this.input.keyboard!;
    const K = Phaser.Input.Keyboard.KeyCodes;
    this.keys = {
      left: kb.addKey(K.LEFT), right: kb.addKey(K.RIGHT), a: kb.addKey(K.A), d: kb.addKey(K.D),
      space: kb.addKey(K.SPACE), c: kb.addKey(K.C), t: kb.addKey(K.T),
    };
    this.keys.space.on('down', () => this.hero.dig());
    this.keys.c.on('down', () => this.hero.cheer());
    this.keys.t.on('down', () => this.hero.takeThat());

    // touch controls (mobile web views); '#noui' hides them for clean captures
    this.input.addPointer(2);
    const ui = !location.hash.includes('noui');
    const by = H - 62;
    ui && new TouchButton(this, 80, by, '◀', 110, 84, () => (this.touchDir = -1), () => (this.touchDir = 0)).setDepth(30);
    ui && new TouchButton(this, 204, by, '▶', 110, 84, () => (this.touchDir = 1), () => (this.touchDir = 0)).setDepth(30);
    ui && new TouchButton(this, W - 470, by, 'DIG', 130, 84, () => this.hero.dig()).setDepth(30);
    ui && new TouchButton(this, W - 320, by, 'CHEER', 150, 84, () => this.hero.cheer()).setDepth(30);
    ui && new TouchButton(this, W - 130, by, 'TAKE THAT', 220, 84, () => this.hero.takeThat()).setDepth(30);

    // automation / save hook (used by the Playwright checks; harmless in production)
    (window as unknown as { __BF: unknown }).__BF = {
      scene: this,
      hero: this.hero,
      state: (): BluefaceState => this.hero.getState(),
    };
  }

  update(_t: number, deltaMs: number) {
    const k = this.keys;
    let dir = this.touchDir;
    if (k.left.isDown || k.a.isDown) dir = -1;
    if (k.right.isDown || k.d.isDown) dir = 1;
    if (dir !== 0) this.hero.walk(dir as -1 | 1);
    else if (this.hero.getAction() === 'walk') this.hero.idle();

    const wd = this.hero.getWalkDir();
    if (wd !== 0) {
      this.hero.x = Phaser.Math.Clamp(this.hero.x + wd * 150 * (deltaMs / 1000), 170, W - 170);
    }
  }

  private makeBackdrop() {
    if (!this.textures.exists('studio')) {
      const tex = this.textures.createCanvas('studio', W, H)!;
      const c = tex.getContext();
      const g = c.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#2c2a2b'); g.addColorStop(0.55, '#413f40'); g.addColorStop(1, '#4c4a4b');
      c.fillStyle = g; c.fillRect(0, 0, W, H);
      const r = c.createRadialGradient(W * 0.5, H * 0.55, 60, W * 0.5, H * 0.55, W * 0.7);
      r.addColorStop(0, 'rgba(255,255,255,0.07)'); r.addColorStop(1, 'rgba(0,0,0,0.35)');
      c.fillStyle = r; c.fillRect(0, 0, W, H);
      tex.refresh();
    }
    this.add.image(0, 0, 'studio').setOrigin(0);
  }

  /** Terraform! a clay mound with a sprout where the spade hit. */
  private spawnMound(x: number, y: number) {
    const g = this.add.graphics({ x, y }).setDepth(5);
    g.fillStyle(0x3a2418, 1).fillEllipse(0, 0, 90, 26);
    g.fillStyle(0x5a3a24, 1).fillEllipse(0, -6, 74, 24);
    g.fillStyle(0x7a5236, 1).fillEllipse(-10, -10, 36, 10);
    g.lineStyle(4, 0x4f8a3a, 1).beginPath(); g.moveTo(0, -12); g.lineTo(2, -34); g.strokePath();
    g.fillStyle(0x6fb04a, 1).fillEllipse(-8, -36, 18, 9).fillEllipse(12, -40, 18, 9);
    g.setScale(0.2, 0);
    this.tweens.add({ targets: g, scaleX: 1, scaleY: 1, duration: 420, ease: 'Back.Out' });
    this.tweens.add({ targets: g, alpha: 0, delay: 5000, duration: 800, onComplete: () => g.destroy() });
  }
}

new Phaser.Game({
  type: Phaser.AUTO,
  parent: 'game',
  width: W,
  height: H,
  backgroundColor: '#3a3839',
  scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
  render: { antialias: true, maxTextures: 1 },
  input: { activePointers: 3 },
  scene: [DemoScene],
});
