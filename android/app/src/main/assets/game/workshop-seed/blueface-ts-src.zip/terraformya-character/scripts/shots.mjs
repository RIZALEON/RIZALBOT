// Headless verification: screenshots + demo video. Usage: node scripts/shots.mjs
import { chromium } from 'playwright';
import { mkdirSync, readdirSync, renameSync, rmSync } from 'node:fs';
import { resolve } from 'node:path';
import { execFileSync } from 'node:child_process';

const root = resolve(import.meta.dirname, '..');
const url = 'file://' + resolve(root, 'dist-single/index.html');
const out = resolve(root, 'shots');
mkdirSync(out, { recursive: true });
rmSync(`${out}/raw`, { recursive: true, force: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });

// 1) stills
{
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  page.on('console', (m) => console.log('[page]', m.text()));
  page.on('pageerror', (e) => console.log('[pageerror]', e.message));
  await page.goto(url);
  await page.waitForFunction(() => window.__BF);
  await sleep(1200);
  await page.screenshot({ path: `${out}/idle.png` });
  const clean = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  await clean.goto(url + '#noui');
  await clean.waitForFunction(() => window.__BF);
  await sleep(1000);
  await clean.screenshot({ path: `${out}/idle-clean.png` });
  await clean.close();
  await page.keyboard.down('ArrowRight');
  await sleep(640);
  await page.screenshot({ path: `${out}/walk.png` });
  await page.keyboard.up('ArrowRight');
  await sleep(700);
  await page.keyboard.down('ArrowLeft');
  await sleep(1000);
  await page.keyboard.up('ArrowLeft');
  await sleep(800);
  await page.keyboard.press('Space');
  await sleep(360);
  await page.screenshot({ path: `${out}/dig-windup.png` });
  await sleep(260);
  await page.screenshot({ path: `${out}/dig.png` });
  await sleep(1400);
  await page.keyboard.press('t');
  await sleep(650);
  await page.screenshot({ path: `${out}/takethat-shout.png` });
  await sleep(1500);
  await page.screenshot({ path: `${out}/takethat-present.png` });
  await sleep(1600);
  await page.keyboard.press('c');
  await sleep(600);
  await page.screenshot({ path: `${out}/cheer.png` });
  console.log('state', JSON.stringify(await page.evaluate(() => window.__BF.state())));
  await page.close();
}

// 2) video: idle -> walk -> dig -> take that (morph) -> cheer
{
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 720 }, recordVideo: { dir: `${out}/raw`, size: { width: 1280, height: 720 } } });
  const page = await ctx.newPage();
  const t0 = Date.now();
  await page.goto(url);
  await page.waitForFunction(() => window.__BF);
  const start = (Date.now() - t0) / 1000;
  await sleep(1100);
  await page.keyboard.down('ArrowRight'); await sleep(1150); await page.keyboard.up('ArrowRight');
  await sleep(200);
  await page.keyboard.press('Space'); await sleep(1400);
  await page.keyboard.press('t'); await sleep(2650);
  await page.keyboard.press('c'); await sleep(1900);
  await ctx.close();
  const f = readdirSync(`${out}/raw`).find((n) => n.endsWith('.webm'));
  renameSync(`${out}/raw/${f}`, `${out}/raw/demo.webm`);
  console.log('video start offset', start.toFixed(2));
}
await browser.close();

// 3) webm -> h264 mp4 (skip the blank page-load frames)
execFileSync('ffmpeg', ['-y', '-loglevel', 'error', '-ss', '0.6', '-i', `${out}/raw/demo.webm`, '-t', '8.9',
  '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '20', '-r', '30', '-movflags', '+faststart', `${out}/blueface-demo.mp4`]);
console.log('wrote shots/blueface-demo.mp4');
