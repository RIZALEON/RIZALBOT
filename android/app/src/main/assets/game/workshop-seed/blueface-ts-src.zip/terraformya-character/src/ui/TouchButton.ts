import Phaser from 'phaser';

/** Rounded on-screen button drawn with Phaser Graphics (touch + mouse). */
export class TouchButton extends Phaser.GameObjects.Container {
  isDown = false;
  private bg: Phaser.GameObjects.Graphics;
  private bw: number;
  private bh: number;

  constructor(scene: Phaser.Scene, x: number, y: number, label: string, w: number, h: number,
    onDown: () => void, onUp?: () => void) {
    super(scene, x, y);
    this.bw = w; this.bh = h;
    this.bg = scene.add.graphics();
    const text = scene.add.text(0, 0, label, {
      fontFamily: '"Arial Black", Arial, sans-serif', fontSize: `${Math.round(h * 0.36)}px`, color: '#f1d09a', resolution: 2,
    }).setOrigin(0.5);
    this.add([this.bg, text]);
    this.draw(false);
    this.setSize(w, h);
    this.setInteractive({ useHandCursor: true });
    this.on('pointerdown', () => { this.isDown = true; this.draw(true); onDown(); });
    const up = () => { if (!this.isDown) return; this.isDown = false; this.draw(false); onUp?.(); };
    this.on('pointerup', up);
    this.on('pointerout', up);
    scene.add.existing(this);
  }

  private draw(down: boolean) {
    const w = this.bw; const h = this.bh;
    const g = this.bg;
    g.clear();
    g.fillStyle(0x000000, 0.35).fillRoundedRect(-w / 2 + 3, -h / 2 + 5, w, h, 18);
    g.fillStyle(down ? 0x2b4f8f : 0x1c3666, 0.92).fillRoundedRect(-w / 2, -h / 2 + (down ? 3 : 0), w, h, 18);
    g.lineStyle(3, 0xc79a5c, 1).strokeRoundedRect(-w / 2, -h / 2 + (down ? 3 : 0), w, h, 18);
  }
}
