import Phaser from 'phaser';
import { PALETTE as P } from './palette';
import { Atlas, clay, clipped, Ctx, mix, quilt, rgba, rng, scales, spot, TexInfo } from './clay';

/**
 * Code-drawn body parts for BLUEFACE. Each function paints one CanvasTexture.
 * Coordinates are in "local units" (1 unit ~ 1px of the 960x540 reference frame).
 */

export interface PartTextures {
  face: TexInfo; eye: TexInfo; brow: TexInfo; grin: TexInfo; shout: TexInfo;
  helmet: TexInfo; horn: TexInfo; ear: TexInfo;
  torso: TexInfo; epaulette: TexInfo;
  upperArm: TexInfo; forearm: TexInfo; hand: TexInfo;
  thigh: TexInfo; shin: TexInfo; boot: TexInfo;
  shaft: TexInfo; axe: TexInfo; spade: TexInfo;
  dirt: string; spark: string;
}

const facePath = (c: Ctx) => {
  c.moveTo(0, 4);
  c.bezierCurveTo(22, 4, 40, -14, 47, -34);
  c.bezierCurveTo(53, -52, 51, -80, 42, -94);
  c.bezierCurveTo(30, -110, -30, -110, -42, -94);
  c.bezierCurveTo(-51, -80, -53, -52, -47, -34);
  c.bezierCurveTo(-40, -14, -22, 4, 0, 4);
};

function drawFace(c: Ctx) {
  clay(c, facePath, P.face, { box: [-52, -108, 104, 112], light: [0.38, 0.3], seed: 11, speckle: 1.2 });
  // eye sockets
  spot(c, -20, -66, 17, 12, P.face.lo, 0.55);
  spot(c, 20, -66, 17, 12, P.face.lo, 0.55);
  // cheek balls pushed up by the grin
  spot(c, -30, -42, 14, 11, P.face.hi, 0.55);
  spot(c, 30, -42, 14, 11, P.face.lo, 0.2);
  spot(c, 26, -44, 11, 9, P.face.hi, 0.35);
  // nose bridge + nose
  spot(c, 0, -66, 5, 12, P.face.hi, 0.45);
  clay(c, (k) => k.ellipse(0, -50, 9, 8, 0, 0, Math.PI * 2), P.face, { box: [-9, -58, 18, 16], seed: 3, shadowBlur: 3, rim: 0.8 });
  c.fillStyle = rgba(P.face.lo, 0.9);
  c.beginPath(); c.ellipse(-4, -45.5, 2.4, 1.5, 0.3, 0, Math.PI * 2); c.fill();
  c.beginPath(); c.ellipse(4, -45.5, 2.4, 1.5, -0.3, 0, Math.PI * 2); c.fill();
  // nasolabial folds
  c.strokeStyle = rgba(mix(P.face.lo, '#000', 0.3), 0.85);
  c.lineWidth = 2;
  c.beginPath(); c.moveTo(-10, -52); c.quadraticCurveTo(-30, -44, -38, -28); c.stroke();
  c.beginPath(); c.moveTo(10, -52); c.quadraticCurveTo(30, -44, 38, -28); c.stroke();
  c.strokeStyle = rgba(P.face.hi, 0.4); c.lineWidth = 1.2;
  c.beginPath(); c.moveTo(-12, -54); c.quadraticCurveTo(-32, -46, -40, -30); c.stroke();
  // chin highlight + dimple
  spot(c, -3, -6, 10, 6, P.face.hi, 0.45);
  // forehead furrows under the helmet rim
  c.strokeStyle = rgba(P.face.lo, 0.5); c.lineWidth = 1;
  c.beginPath(); c.moveTo(-10, -88); c.quadraticCurveTo(0, -91, 10, -88); c.stroke();
}

function drawEye(c: Ctx) {
  // lid shadow ring
  c.fillStyle = rgba('#07142f', 0.9);
  c.beginPath(); c.ellipse(0, 0, 12.5, 10, 0, 0, Math.PI * 2); c.fill();
  const g = c.createRadialGradient(-3, -3, 1, 0, 0, 12);
  g.addColorStop(0, '#ffffff'); g.addColorStop(0.7, P.eyeWhite); g.addColorStop(1, '#b9b3a8');
  c.fillStyle = g;
  c.beginPath(); c.ellipse(0, 0.6, 11, 8.4, 0, 0, Math.PI * 2); c.fill();
  // upper lid shade
  spot(c, 0, -6, 11, 4, '#5a6a8a', 0.5);
  // pupil (iris dark brown/black)
  c.fillStyle = '#3a2418';
  c.beginPath(); c.arc(0, 0.8, 5.6, 0, Math.PI * 2); c.fill();
  c.fillStyle = P.pupil;
  c.beginPath(); c.arc(0, 0.8, 3.9, 0, Math.PI * 2); c.fill();
  c.fillStyle = '#ffffff';
  c.beginPath(); c.arc(-1.8, -1.2, 1.5, 0, Math.PI * 2); c.fill();
}

function drawBrow(c: Ctx) {
  const path = (k: Ctx) => {
    k.moveTo(-17, 5);
    k.quadraticCurveTo(-4, -11, 17, -3);
    k.quadraticCurveTo(19, 1, 15, 2.5);
    k.quadraticCurveTo(-2, -3, -15, 9);
    k.closePath();
  };
  clay(c, path, P.brow, { box: [-17, -9, 36, 18], seed: 5, shadowBlur: 4, rim: 1 });
  // hair strokes
  const r = rng(9);
  c.strokeStyle = rgba(P.brow.lo, 0.7); c.lineWidth = 0.8;
  for (let i = 0; i < 16; i++) {
    const t = i / 15;
    const x = -14 + t * 29;
    const y = 5 - Math.sin(t * Math.PI) * 9 + t * -4 + 2;
    c.beginPath(); c.moveTo(x, y); c.lineTo(x + 3 + r() * 2, y - 3 - r() * 2); c.stroke();
  }
}

const grinPath = (k: Ctx) => {
  k.moveTo(-35, -7);
  k.quadraticCurveTo(0, 4, 35, -7);
  k.quadraticCurveTo(26, 20, 0, 23);
  k.quadraticCurveTo(-26, 20, -35, -7);
  k.closePath();
};

function drawGrin(c: Ctx) {
  c.fillStyle = P.mouth.inside;
  c.beginPath(); grinPath(c); c.fill();
  clipped(c, grinPath, () => {
    // upper teeth
    for (let i = -4; i < 4; i++) {
      const x = i * 8.2 + 4.1;
      const top = -3 + Math.abs(x) * Math.abs(x) * 0.0035 - 3;
      const bot = 9 - Math.abs(x) * 0.12;
      const g = c.createLinearGradient(x - 4, 0, x + 4, 0);
      g.addColorStop(0, P.teeth.lo); g.addColorStop(0.35, '#ffffff'); g.addColorStop(1, P.teeth.base);
      c.fillStyle = g;
      c.beginPath(); c.roundRect(x - 3.7, top - 6, 7.4, bot - top + 6, 2.5); c.fill();
    }
    // lower teeth
    for (let i = -4; i < 4; i++) {
      const x = i * 7.6 + 3.8;
      const top = 11 - Math.abs(x) * 0.12;
      const g = c.createLinearGradient(x - 4, 0, x + 4, 0);
      g.addColorStop(0, P.teeth.lo); g.addColorStop(0.4, '#fbf7ec'); g.addColorStop(1, P.teeth.base);
      c.fillStyle = g;
      c.beginPath(); c.roundRect(x - 3.4, top, 6.8, 16, 2.2); c.fill();
    }
    // bite line shadow
    c.strokeStyle = rgba(P.mouth.inside, 0.9); c.lineWidth = 1.6;
    c.beginPath(); c.moveTo(-34, 2); c.quadraticCurveTo(0, 16, 34, 2); c.stroke();
    spot(c, 0, -4, 30, 5, '#000000', 0.25);
  });
  // lips
  c.strokeStyle = P.mouth.lip; c.lineWidth = 2.6;
  c.beginPath(); grinPath(c); c.stroke();
  // corner creases
  c.strokeStyle = rgba('#07142f', 0.8); c.lineWidth = 1.6;
  c.beginPath(); c.moveTo(-36, -12); c.quadraticCurveTo(-40, -6, -36, -1); c.stroke();
  c.beginPath(); c.moveTo(36, -12); c.quadraticCurveTo(40, -6, 36, -1); c.stroke();
}

const shoutPath = (k: Ctx) => {
  k.moveTo(-30, -6);
  k.quadraticCurveTo(0, -14, 30, -6);
  k.bezierCurveTo(30, 18, 14, 36, 0, 36);
  k.bezierCurveTo(-14, 36, -30, 18, -30, -6);
  k.closePath();
};

function drawShout(c: Ctx) {
  c.fillStyle = P.mouth.inside;
  c.beginPath(); shoutPath(c); c.fill();
  clipped(c, shoutPath, () => {
    spot(c, 0, 14, 20, 14, '#000000', 0.5);
    c.fillStyle = P.mouth.tongue;
    c.beginPath(); c.ellipse(0, 30, 16, 9, 0, 0, Math.PI * 2); c.fill();
    spot(c, -4, 27, 7, 3, '#ff9aa8', 0.5);
    for (let i = -3; i < 4; i++) {
      c.fillStyle = i % 2 ? P.teeth.base : '#fbf7ec';
      c.beginPath(); c.roundRect(i * 8 - 3.6, -14, 7.2, 12 - Math.abs(i) * 1.2, 2.4); c.fill();
    }
    for (let i = -2; i < 3; i++) {
      c.fillStyle = P.teeth.base;
      c.beginPath(); c.roundRect(i * 8 - 3.4, 30 - Math.abs(i) * 3, 6.8, 10, 2); c.fill();
    }
  });
  c.strokeStyle = P.mouth.lip; c.lineWidth = 2.6;
  c.beginPath(); shoutPath(c); c.stroke();
}

const helmetPath = (k: Ctx) => {
  k.moveTo(-52, -36);
  k.bezierCurveTo(-60, -60, -66, -90, -63, -112);
  k.bezierCurveTo(-60, -146, -34, -162, 0, -163);
  k.bezierCurveTo(34, -162, 60, -146, 63, -112);
  k.bezierCurveTo(66, -90, 60, -60, 52, -36);
  k.lineTo(43, -40);
  k.bezierCurveTo(48, -60, 48, -80, 42, -90);
  k.quadraticCurveTo(0, -104, -42, -90);
  k.bezierCurveTo(-48, -80, -48, -60, -43, -40);
  k.closePath();
};

function drawHelmet(c: Ctx) {
  clay(c, helmetPath, P.helmet, { box: [-66, -178, 132, 142], light: [0.32, 0.18], seed: 21, speckle: 0.6, shadowBlur: 6 });
  clipped(c, helmetPath, () => {
    scales(c, [-66, -176, 132, 140], 11, 8.5, mix(P.helmet.lo, '#000', 0.2), P.helmet.hi, 4);
    // central raised ridge
    const g = c.createLinearGradient(-6, 0, 6, 0);
    g.addColorStop(0, P.helmet.lo); g.addColorStop(0.45, P.helmet.hi); g.addColorStop(1, P.helmet.base);
    c.fillStyle = g;
    c.beginPath(); c.roundRect(-5, -164, 10, 66, 4); c.fill();
    spot(c, -26, -142, 26, 14, '#fff2d0', 0.4);
    spot(c, 40, -80, 30, 40, P.helmet.lo, 0.5);
  });
  // rim band over the brow + around the face opening
  c.strokeStyle = P.helmet.lo; c.lineWidth = 7;
  c.beginPath();
  c.moveTo(-43, -40); c.bezierCurveTo(-48, -60, -48, -80, -42, -90);
  c.quadraticCurveTo(0, -104, 42, -90); c.bezierCurveTo(48, -80, 48, -60, 43, -40);
  c.stroke();
  c.strokeStyle = P.gold.base; c.lineWidth = 4.5; c.stroke();
  c.strokeStyle = rgba(P.gold.hi, 0.8); c.lineWidth = 1.4;
  c.beginPath(); c.moveTo(-42, -92); c.quadraticCurveTo(0, -106, 42, -92); c.stroke();
  // rivets on band
  for (let i = -3; i <= 3; i++) {
    const x = i * 11;
    const y = -97 + Math.abs(x) * Math.abs(x) * 0.0033 - 0.5;
    c.fillStyle = P.helmet.lo; c.beginPath(); c.arc(x, y + 0.6, 2.1, 0, Math.PI * 2); c.fill();
    c.fillStyle = P.gold.hi; c.beginPath(); c.arc(x - 0.4, y, 1.4, 0, Math.PI * 2); c.fill();
  }
}

function drawHorn(c: Ctx) {
  const path = (k: Ctx) => {
    k.moveTo(-11, 6);
    k.bezierCurveTo(-38, -8, -38, -48, -6, -68);
    k.bezierCurveTo(-18, -46, -14, -20, 11, -2);
    k.closePath();
  };
  clay(c, path, P.horn, { box: [-34, -68, 46, 74], light: [0.25, 0.35], seed: 31, shadowBlur: 5 });
  clipped(c, path, () => {
    c.strokeStyle = rgba(P.horn.lo, 0.8); c.lineWidth = 1.4;
    for (let i = 0; i < 7; i++) {
      const y = 2 - i * 9;
      c.beginPath(); c.moveTo(-40, y - 6 + i * 0.5); c.quadraticCurveTo(-10, y + 4, 14, y - 4); c.stroke();
    }
    c.strokeStyle = rgba(P.horn.hi, 0.7); c.lineWidth = 2.5;
    c.beginPath(); c.moveTo(-8, 0); c.bezierCurveTo(-30, -12, -30, -44, -8, -62); c.stroke();
  });
}

function drawEar(c: Ctx) {
  const path = (k: Ctx) => {
    k.moveTo(6, -14);
    k.quadraticCurveTo(-18, -24, -54, -46);
    k.quadraticCurveTo(-40, -2, 4, 17);
    k.closePath();
  };
  clay(c, path, P.ear, { box: [-54, -46, 60, 63], light: [0.4, 0.2], seed: 41, shadowBlur: 5 });
  const inner = (k: Ctx) => {
    k.moveTo(2, -8);
    k.quadraticCurveTo(-18, -16, -42, -35);
    k.quadraticCurveTo(-30, -4, 0, 9);
    k.closePath();
  };
  clay(c, inner, { base: P.ear.inner, lo: '#24092a', hi: '#a4629a' }, { box: [-42, -35, 44, 44], light: [0.6, 0.6], seed: 43, shadowBlur: 0, rim: 0.8 });
}

const torsoPath = (k: Ctx) => {
  k.moveTo(-24, -122);
  k.bezierCurveTo(-40, -118, -56, -116, -64, -106);
  k.bezierCurveTo(-72, -94, -66, -70, -62, -52);
  k.bezierCurveTo(-58, -30, -58, -14, -56, 10);
  k.lineTo(56, 10);
  k.bezierCurveTo(58, -14, 58, -30, 62, -52);
  k.bezierCurveTo(66, -70, 72, -94, 64, -106);
  k.bezierCurveTo(56, -116, 40, -118, 24, -122);
  k.closePath();
};

function button(c: Ctx, x: number, y: number, r: number) {
  c.fillStyle = rgba('#000', 0.45); c.beginPath(); c.arc(x + 0.8, y + 1.2, r, 0, Math.PI * 2); c.fill();
  const g = c.createRadialGradient(x - r * 0.4, y - r * 0.4, 0.3, x, y, r);
  g.addColorStop(0, P.gold.hi); g.addColorStop(0.55, P.gold.base); g.addColorStop(1, P.gold.lo);
  c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill();
}

function drawTorso(c: Ctx) {
  clay(c, torsoPath, P.jacket, { box: [-70, -124, 140, 134], light: [0.62, 0.25], seed: 51, shadowBlur: 6, hiAlpha: 0.75 });
  clipped(c, torsoPath, () => {
    quilt(c, [-72, -124, 144, 136], 10, mix(P.jacket.lo, '#000', 0.4), P.jacket.hi);
    // placket panel + gold piping forming the V under the collar
    c.fillStyle = rgba(P.jacket.lo, 0.45);
    c.beginPath(); c.moveTo(-9, -118); c.lineTo(9, -118); c.lineTo(6, 10); c.lineTo(-6, 10); c.fill();
    c.strokeStyle = P.gold.base; c.lineWidth = 1.8;
    c.beginPath(); c.moveTo(-20, -120); c.quadraticCurveTo(-4, -104, -3, -80); c.lineTo(-3, 10); c.stroke();
    c.beginPath(); c.moveTo(20, -120); c.quadraticCurveTo(4, -104, 3, -80); c.lineTo(3, 10); c.stroke();
    spot(c, -40, 0, 30, 18, '#000', 0.35);
  });
  // stand collar: blue with red trim + gold piping
  const collar = (k: Ctx) => { k.roundRect(-26, -136, 52, 18, 6); };
  clay(c, collar, P.jacket, { box: [-26, -136, 52, 18], seed: 52, shadowBlur: 3 });
  c.strokeStyle = P.collarRed; c.lineWidth = 3.4;
  c.beginPath(); c.moveTo(-24, -133); c.quadraticCurveTo(0, -128, 24, -133); c.stroke();
  c.strokeStyle = P.gold.base; c.lineWidth = 1.4;
  c.beginPath(); c.moveTo(-25, -121); c.quadraticCurveTo(0, -116, 25, -121); c.stroke();
  // buttons: two rows
  for (let i = 0; i < 4; i++) {
    button(c, -15, -96 + i * 20, 4.2);
    button(c, 15, -96 + i * 20, 4.2);
  }
  // medallion on the chest
  button(c, 38, -82, 9.5);
  c.strokeStyle = rgba(P.gold.lo, 0.9); c.lineWidth = 1.2;
  c.beginPath(); c.arc(38, -82, 6, 0, Math.PI * 2); c.stroke();
  c.beginPath(); c.arc(38, -82, 2.6, 0, Math.PI * 2); c.stroke();
  // belt
  const belt = (k: Ctx) => {
    k.moveTo(-58, -8); k.quadraticCurveTo(0, -3, 58, -8); k.lineTo(58, 7); k.quadraticCurveTo(0, 12, -58, 7); k.closePath();
  };
  clay(c, belt, P.belt, { box: [-58, -8, 116, 20], seed: 53, shadowBlur: 4 });
  c.setLineDash([2.5, 2.5]); c.strokeStyle = rgba(P.lace, 0.55); c.lineWidth = 0.8;
  c.beginPath(); c.moveTo(-56, -5); c.quadraticCurveTo(0, 0, 56, -5); c.stroke();
  c.beginPath(); c.moveTo(-56, 4.5); c.quadraticCurveTo(0, 9.5, 56, 4.5); c.stroke();
  c.setLineDash([]);
  // pouches
  for (const sx of [-1, 1]) {
    const px = sx * 46;
    const pouch = (k: Ctx) => { k.roundRect(px - 9, -2, 18, 24, 4); };
    clay(c, pouch, P.belt, { box: [px - 9, -2, 18, 24], seed: 54 + sx, shadowBlur: 4 });
    const flap = (k: Ctx) => { k.moveTo(px - 10, -3); k.lineTo(px + 10, -3); k.lineTo(px + 9, 8); k.quadraticCurveTo(px, 13, px - 9, 8); k.closePath(); };
    clay(c, flap, { base: mix(P.belt.base, P.belt.hi, 0.3), lo: P.belt.lo, hi: P.belt.hi }, { box: [px - 10, -3, 20, 16], seed: 60, shadowBlur: 3 });
    button(c, px, 8, 1.8);
  }
  // red emblem buckle
  c.fillStyle = P.gold.lo; c.beginPath(); c.roundRect(-9, -8, 18, 16, 3); c.fill();
  const bg = c.createLinearGradient(0, -7, 0, 7);
  bg.addColorStop(0, '#d9504a'); bg.addColorStop(1, '#7e1c1c');
  c.fillStyle = bg; c.beginPath(); c.roundRect(-7, -6, 14, 12, 2); c.fill();
  c.strokeStyle = P.gold.hi; c.lineWidth = 1; c.beginPath(); c.moveTo(-3, -3); c.lineTo(3, 3); c.moveTo(3, -3); c.lineTo(-3, 3); c.stroke();
}

function drawEpaulette(c: Ctx) {
  // fringe
  for (let i = 0; i < 10; i++) {
    const x = -22 + i * 4.6;
    const len = 20 + Math.sin(i * 0.9) * 2 + (i < 3 ? 4 : 0);
    const ang = -0.25 + i * 0.03;
    c.save();
    c.translate(x, 3);
    c.rotate(ang);
    const g = c.createLinearGradient(-2.4, 0, 2.4, 0);
    g.addColorStop(0, P.epaulette.lo); g.addColorStop(0.45, P.epaulette.hi); g.addColorStop(1, P.epaulette.lo);
    c.fillStyle = g;
    c.beginPath(); c.roundRect(-2.4, 0, 4.8, len, 2.4); c.fill();
    c.restore();
  }
  const board = (k: Ctx) => { k.ellipse(0, 0, 25, 9.5, -0.06, 0, Math.PI * 2); };
  clay(c, board, P.epaulette, { box: [-25, -10, 50, 20], seed: 71, shadowBlur: 4 });
  c.strokeStyle = P.gold.hi; c.lineWidth = 1.2;
  c.beginPath(); c.ellipse(0, 0, 21, 7, -0.06, 0, Math.PI * 2); c.stroke();
  // green gem
  const gg = c.createRadialGradient(-5, -1.8, 0.3, -4, -1, 4);
  gg.addColorStop(0, P.gem.hi); gg.addColorStop(0.5, P.gem.base); gg.addColorStop(1, P.gem.lo);
  c.fillStyle = P.gold.lo; c.beginPath(); c.arc(-4, -1, 4.6, 0, Math.PI * 2); c.fill();
  c.fillStyle = gg; c.beginPath(); c.arc(-4, -1, 3.6, 0, Math.PI * 2); c.fill();
}

function drawUpperArm(c: Ctx) {
  const path = (k: Ctx) => { k.roundRect(-15, -16, 72, 32, 15); };
  clay(c, path, { ...P.jacket, base: '#2a4c8a' }, { box: [-15, -16, 72, 32], light: [0.4, 0.2], seed: 81, shadowBlur: 5, hiAlpha: 1 });
  clipped(c, path, () => quilt(c, [-15, -16, 72, 32], 9, mix(P.jacket.lo, '#000', 0.4), P.jacket.hi));
  c.strokeStyle = rgba(P.jacket.hi, 0.9); c.lineWidth = 2.2;
  c.beginPath(); c.moveTo(-4, -12); c.lineTo(48, -12); c.stroke();
}

function drawForearm(c: Ctx) {
  const path = (k: Ctx) => { k.roundRect(-13, -14, 66, 28, 13); };
  clay(c, path, { ...P.jacket, base: '#2a4c8a' }, { box: [-13, -14, 66, 28], light: [0.4, 0.2], seed: 82, shadowBlur: 5, hiAlpha: 1 });
  clipped(c, path, () => quilt(c, [-13, -14, 36, 28], 9, mix(P.jacket.lo, '#000', 0.4), P.jacket.hi));
  c.strokeStyle = rgba(P.jacket.hi, 0.9); c.lineWidth = 2;
  c.beginPath(); c.moveTo(-6, -11); c.lineTo(20, -11); c.stroke();
  // maroon cuff
  const cuff = (k: Ctx) => { k.roundRect(16, -17, 28, 34, 9); };
  clay(c, cuff, P.cuff, { box: [16, -17, 28, 34], seed: 83, shadowBlur: 4, hiAlpha: 1 });
  clipped(c, cuff, () => quilt(c, [16, -17, 28, 34], 7, mix(P.cuff.lo, '#000', 0.3), P.cuff.hi));
  // gold bangle at wrist
  c.strokeStyle = P.gold.base; c.lineWidth = 3.4;
  c.beginPath(); c.moveTo(43, -15); c.lineTo(43, 15); c.stroke();
  c.strokeStyle = P.gold.hi; c.lineWidth = 1; c.beginPath(); c.moveTo(42.2, -12); c.lineTo(42.2, 4); c.stroke();
}

function drawHand(c: Ctx) {
  // fingers wrap around the shaft (shaft runs along x through 0,0)
  for (let i = 0; i < 4; i++) {
    const x = -11 + i * 7.3;
    const f = (k: Ctx) => { k.roundRect(x - 3.9, -13 + (i === 0 || i === 3 ? 2 : 0), 7.8, 25 - (i === 3 ? 3 : 0), 3.9); };
    clay(c, f, P.hand, { box: [x - 4, -13, 8, 25], light: [0.35, 0.25], seed: 90 + i, shadowBlur: 2.5, rim: 1 });
  }
  // back of hand / knuckles
  const back = (k: Ctx) => { k.ellipse(1, -9, 16, 7.5, 0, 0, Math.PI * 2); };
  clay(c, back, P.hand, { box: [-15, -17, 32, 15], light: [0.3, 0.2], seed: 95, shadowBlur: 3 });
  // thumb across the front
  const thumb = (k: Ctx) => { k.ellipse(-4, 4, 12, 5.2, -0.45, 0, Math.PI * 2); };
  clay(c, thumb, P.hand, { box: [-16, -2, 24, 12], light: [0.3, 0.2], seed: 96, shadowBlur: 3 });
}

const thighPath = (k: Ctx) => {
  k.moveTo(-30, -6);
  k.lineTo(30, -6);
  k.bezierCurveTo(40, 20, 40, 64, 27, 100);
  k.lineTo(-27, 100);
  k.bezierCurveTo(-40, 64, -40, 20, -30, -6);
  k.closePath();
};

function pantsTexture(c: Ctx, box: [number, number, number, number], seed: number) {
  scales(c, box, 7.5, 6, mix(P.pants.lo, '#000', 0.25), P.pants.hi, seed, 0.8);
}

function drawThigh(c: Ctx) {
  clay(c, thighPath, P.pants, { box: [-38, -6, 76, 106], light: [0.3, 0.25], seed: 101, shadowBlur: 5, speckle: 1.5 });
  clipped(c, thighPath, () => {
    pantsTexture(c, [-40, -6, 80, 108], 3);
    c.strokeStyle = rgba(P.pants.lo, 0.8); c.lineWidth = 1.8;
    c.beginPath(); c.moveTo(-18, 30); c.quadraticCurveTo(0, 38, 20, 26); c.stroke();
    c.beginPath(); c.moveTo(-20, 66); c.quadraticCurveTo(-2, 74, 18, 64); c.stroke();
  });
}

function drawShin(c: Ctx) {
  const path = (k: Ctx) => {
    k.moveTo(-27, -8); k.lineTo(27, -8);
    k.bezierCurveTo(33, 20, 35, 44, 28, 56);
    k.quadraticCurveTo(0, 62, -28, 56);
    k.bezierCurveTo(-35, 44, -33, 20, -27, -8);
    k.closePath();
  };
  clay(c, path, P.pants, { box: [-35, -8, 70, 68], light: [0.3, 0.25], seed: 111, shadowBlur: 5, speckle: 1.5 });
  clipped(c, path, () => {
    pantsTexture(c, [-30, -8, 60, 68], 5);
    c.strokeStyle = rgba(P.pants.lo, 0.8); c.lineWidth = 1.8;
    c.beginPath(); c.moveTo(-22, 38); c.quadraticCurveTo(0, 46, 24, 36); c.stroke();
    c.beginPath(); c.moveTo(-24, 48); c.quadraticCurveTo(0, 55, 25, 47); c.stroke();
  });
}

function drawBoot(c: Ctx) {
  // toe points to -x (viewer left) in the texture
  const upper = (k: Ctx) => {
    k.moveTo(-18, -4); k.lineTo(18, -4);
    k.bezierCurveTo(22, 14, 24, 30, 24, 44);
    k.lineTo(-40, 44);
    k.bezierCurveTo(-50, 44, -52, 30, -38, 26);
    k.bezierCurveTo(-26, 22, -20, 14, -18, -4);
    k.closePath();
  };
  clay(c, upper, P.boot, { box: [-52, -4, 76, 48], light: [0.3, 0.2], seed: 121, shadowBlur: 5, speckle: 2.2 });
  clipped(c, upper, () => {
    const r = rng(7);
    c.strokeStyle = rgba(P.boot.lo, 0.6); c.lineWidth = 0.9;
    for (let i = 0; i < 40; i++) {
      const x = -50 + r() * 74; const y = -4 + r() * 48;
      c.beginPath(); c.moveTo(x, y); c.lineTo(x + 3 + r() * 3, y + (r() - 0.5) * 2); c.stroke();
    }
    spot(c, -36, 30, 10, 7, P.boot.hi, 0.5);
  });
  // laces criss-cross on the front
  c.strokeStyle = P.lace; c.lineWidth = 1.4;
  for (let i = 0; i < 5; i++) {
    const y = 2 + i * 6.5;
    const x0 = -16 + i * -2.4;
    c.beginPath(); c.moveTo(x0, y); c.lineTo(x0 + 12, y + 5); c.moveTo(x0 + 12, y); c.lineTo(x0, y + 5); c.stroke();
  }
  // sole
  const sole = (k: Ctx) => { k.roundRect(-46, 42, 72, 9, 4); };
  clay(c, sole, { base: '#4a2c1c', lo: '#1e0f08', hi: '#6e4a34' }, { box: [-46, 42, 72, 9], seed: 122, shadowBlur: 3 });
  c.strokeStyle = rgba('#000', 0.35); c.lineWidth = 0.8;
  for (let x = -42; x < 24; x += 5) { c.beginPath(); c.moveTo(x, 47); c.lineTo(x + 2, 50); c.stroke(); }
}

function drawShaft(c: Ctx) {
  const path = (k: Ctx) => { k.roundRect(-166, -6, 332, 12, 6); };
  clay(c, path, P.wood, { box: [-166, -6, 332, 12], light: [0.5, 0.1], seed: 131, shadowBlur: 4, speckle: 0.6 });
  clipped(c, path, () => {
    const r = rng(13);
    for (let i = 0; i < 16; i++) {
      const y = -5 + r() * 10;
      c.strokeStyle = r() < 0.6 ? rgba(P.wood.lo, 0.55) : rgba(P.wood.hi, 0.4);
      c.lineWidth = 0.7 + r() * 0.6;
      c.beginPath(); c.moveTo(-166, y);
      for (let x = -166; x <= 166; x += 20) c.lineTo(x, y + Math.sin(x * 0.05 + i) * 1.2);
      c.stroke();
    }
    c.fillStyle = rgba('#fff', 0.18); c.fillRect(-166, -4, 332, 2);
  });
}

const axeBlade = (k: Ctx) => {
  k.moveTo(-2, 7);
  k.lineTo(24, 7);
  k.quadraticCurveTo(34, 52, 78, 118);
  k.quadraticCurveTo(12, 156, -70, 112);
  k.quadraticCurveTo(-20, 62, -2, 7);
  k.closePath();
};
const axePick = (k: Ctx) => {
  k.moveTo(0, -7);
  k.lineTo(22, -7);
  k.quadraticCurveTo(14, -48, -34, -86);
  k.quadraticCurveTo(-8, -44, 0, -7);
  k.closePath();
};

function damascus(c: Ctx, box: [number, number, number, number], seed: number) {
  const [x, y, w, h] = box;
  const r = rng(seed);
  for (let i = 0; i < 46; i++) {
    const yy = y + (i / 46) * h;
    const ph = r() * 6;
    const amp = 3 + r() * 5;
    c.strokeStyle = i % 2 ? rgba('#e6e3e0', 0.45) : rgba('#4a4b4d', 0.45);
    c.lineWidth = 1 + r();
    c.beginPath();
    for (let xx = x; xx <= x + w; xx += 4) {
      const v = yy + Math.sin(xx * 0.09 + ph) * amp + Math.sin(xx * 0.23 + ph * 2) * amp * 0.4;
      if (xx === x) c.moveTo(xx, v); else c.lineTo(xx, v);
    }
    c.stroke();
  }
}

function drawAxe(c: Ctx) {
  clay(c, axeBlade, P.steel, { box: [-70, 7, 148, 140], light: [0.3, 0.3], seed: 141, shadowBlur: 6, speckle: 0.2 });
  clipped(c, axeBlade, () => {
    damascus(c, [-72, 0, 152, 150], 5);
    // bright bevel along the cutting edge
    c.strokeStyle = rgba('#f2f0ee', 0.75); c.lineWidth = 7;
    c.beginPath(); c.moveTo(78, 118); c.quadraticCurveTo(12, 156, -70, 112); c.stroke();
  });
  clay(c, axePick, P.steel, { box: [-34, -86, 56, 80], light: [0.4, 0.3], seed: 142, shadowBlur: 5, speckle: 0.2 });
  clipped(c, axePick, () => damascus(c, [-36, -88, 60, 84], 6));
  // socket collar
  const sock = (k: Ctx) => { k.roundRect(-4, -10, 30, 20, 4); };
  clay(c, sock, { base: '#6d6e70', lo: '#2f3032', hi: '#c9c6c3' }, { box: [-4, -10, 30, 20], seed: 143, shadowBlur: 4 });
  for (const x of [4, 18]) { c.fillStyle = '#d9d6d2'; c.beginPath(); c.arc(x, 0, 1.8, 0, Math.PI * 2); c.fill(); }
}

const spadeBlade = (k: Ctx) => {
  k.moveTo(22, -6);
  k.lineTo(18, -38);
  k.quadraticCurveTo(24, -42, 34, -41);
  k.quadraticCurveTo(92, -38, 124, 0);
  k.quadraticCurveTo(92, 38, 34, 41);
  k.quadraticCurveTo(24, 42, 18, 38);
  k.lineTo(22, 6);
  k.closePath();
};

function drawSpade(c: Ctx) {
  // iridescent blade
  c.save();
  c.shadowColor = 'rgba(0,0,0,0.4)'; c.shadowBlur = 6; c.shadowOffsetY = 2;
  const g = c.createLinearGradient(18, -42, 124, 42);
  P.iri.forEach((col, i) => g.addColorStop(i / (P.iri.length - 1), col));
  c.fillStyle = g;
  c.beginPath(); spadeBlade(c); c.fill();
  c.restore();
  clipped(c, spadeBlade, () => {
    spot(c, 60, -8, 40, 26, '#8a6fc8', 0.55); // purple bloom
    spot(c, 88, 14, 30, 18, '#f0c06a', 0.5); // gold bloom
    spot(c, 44, 22, 26, 14, '#ff9ec0', 0.45); // pink bloom
    spot(c, 50, -24, 24, 10, '#ffffff', 0.45); // sheen
    c.strokeStyle = rgba('#ffffff', 0.25); c.lineWidth = 3;
    for (let i = 0; i < 4; i++) { c.beginPath(); c.moveTo(30 + i * 22, -40); c.lineTo(10 + i * 22, 40); c.stroke(); }
  });
  // silver rim
  c.strokeStyle = '#e9e4ea'; c.lineWidth = 2.6;
  c.beginPath(); spadeBlade(c); c.stroke();
  c.strokeStyle = rgba('#5b5160', 0.8); c.lineWidth = 0.9;
  c.beginPath(); spadeBlade(c); c.stroke();
  // steel socket spike running into the blade
  const spike = (k: Ctx) => { k.moveTo(-16, -7); k.lineTo(8, -8); k.lineTo(76, 0); k.lineTo(8, 8); k.lineTo(-16, 7); k.closePath(); };
  clay(c, spike, { base: '#8e9092', lo: '#3a3b3d', hi: '#e8e6e2' }, { box: [-16, -8, 92, 16], light: [0.3, 0.1], seed: 151, shadowBlur: 4, speckle: 0.1 });
  c.strokeStyle = rgba('#2a2a2c', 0.8); c.lineWidth = 1;
  c.beginPath(); c.moveTo(8, 0); c.lineTo(74, 0); c.stroke();
}

export function buildParts(scene: Phaser.Scene): PartTextures {
  const atlas = new Atlas(scene, 'bf-atlas');
  const t = (k: string, w: number, h: number, px: number, py: number, d: (c: Ctx) => void) =>
    atlas.add(k, w, h, px, py, d);

  // tiny effect textures made with Phaser Graphics + generateTexture
  if (!scene.textures.exists('bf-dirt')) {
    const g = scene.make.graphics({ x: 0, y: 0 }, false);
    g.fillStyle(0x5a3a24, 1); g.fillCircle(6, 6, 6);
    g.fillStyle(0x8a5e3c, 1); g.fillCircle(4.5, 4.5, 3);
    g.generateTexture('bf-dirt', 12, 12);
    g.clear();
    g.fillStyle(0xffffff, 1); g.fillCircle(6, 6, 2.5);
    g.fillStyle(0xfff0c0, 0.6); g.fillCircle(6, 6, 5);
    g.generateTexture('bf-spark', 12, 12);
    g.destroy();
  }

  const parts: PartTextures = {
    face: t('face', 124, 136, 62, 120, drawFace),
    eye: t('eye', 30, 26, 15, 13, drawEye),
    brow: t('brow', 46, 30, 22, 14, drawBrow),
    grin: t('grin', 90, 44, 45, 16, drawGrin),
    shout: t('shout', 76, 60, 38, 20, drawShout),
    helmet: t('helmet', 150, 166, 75, 192, drawHelmet),
    horn: t('horn', 64, 90, 44, 78, drawHorn),
    ear: t('ear', 76, 78, 64, 54, drawEar),
    torso: t('torso', 164, 180, 82, 148, drawTorso),
    epaulette: t('epaulette', 64, 48, 32, 14, drawEpaulette),
    upperArm: t('upperArm', 90, 44, 22, 22, drawUpperArm),
    forearm: t('forearm', 84, 42, 20, 21, drawForearm),
    hand: t('hand', 46, 40, 22, 20, drawHand),
    thigh: t('thigh', 92, 122, 46, 12, drawThigh),
    shin: t('shin', 84, 82, 42, 14, drawShin),
    boot: t('boot', 92, 68, 58, 10, drawBoot),
    shaft: t('shaft', 346, 26, 173, 13, drawShaft),
    axe: t('axe', 168, 256, 84, 98, drawAxe),
    spade: t('spade', 158, 100, 24, 50, drawSpade),
    dirt: 'bf-dirt',
    spark: 'bf-spark',
  };
  atlas.done();
  return parts;
}
