import Phaser from 'phaser';
import { buildParts, PartTextures } from './parts';
import { RES, TexInfo } from './clay';
import type { BluefaceAction, BluefaceFacing, BluefaceState, BluefaceTool } from './state';

export type { BluefaceState } from './state';

/** Numeric pose channels; every frame the rig eases toward a target pose. */
interface Pose {
  bodyY: number; bodyRot: number; headRot: number; lift: number;
  hipL: number; kneeL: number; hipR: number; kneeR: number;
  toolX: number; toolY: number; toolRot: number;
  g1: number; g2: number; // grip positions along the tool (arm1 = viewer-left shoulder, arm2 = viewer-right)
  brow: number;
  free1: number; fx1: number; fy1: number; // arm1 lets go of the tool (0..1) and reaches for (fx1, fy1)
}

const IDLE: Pose = {
  bodyY: 0, bodyRot: 0, headRot: 0, lift: 0,
  hipL: 0.42, kneeL: -0.24, hipR: -0.42, kneeR: 0.24,
  toolX: -78, toolY: -262, toolRot: 1.02, g1: -82, g2: 84, brow: 0, free1: 0, fx1: -100, fy1: -385,
};
// walk: tool carried across the body, axe end forward-low with the blade up so the stride stays visible
const WALK: Pose = { ...IDLE, hipL: 0, kneeL: 0, hipR: 0, kneeR: 0, toolX: 40, toolY: -250, toolRot: Math.PI + 0.42, g1: 48, g2: -62, bodyRot: 0.05 };
const DIG_UP: Pose = { ...IDLE, toolX: 40, toolY: -372, toolRot: -1.2, g1: 10, g2: 70, bodyRot: -0.1, headRot: -0.08, hipL: 0.3, kneeL: -0.1, hipR: -0.3, kneeR: 0.1, brow: -3 };
const DIG_DOWN: Pose = { ...IDLE, toolX: -26, toolY: -214, toolRot: 0.95, g1: -40, g2: 30, bodyRot: 0.14, headRot: 0.1, hipL: 0.5, kneeL: -0.55, hipR: -0.5, kneeR: 0.55, brow: 2 };
const CHEER: Pose = { ...IDLE, toolX: 110, toolY: -392, toolRot: -1.45, g1: -58, g2: -10, free1: 1, fx1: -100, fy1: -388, headRot: -0.1, brow: -5, hipL: 0.22, kneeL: -0.1, hipR: -0.22, kneeR: 0.1 };
const TAKE_THAT: Pose = { ...IDLE, toolX: 18, toolY: -262, toolRot: -0.34, g1: -44, g2: 92, bodyRot: -0.06, headRot: -0.12, brow: -5, hipL: 0.42, kneeL: -0.3, hipR: -0.42, kneeR: 0.3 };
const PRESENT: Pose = { ...IDLE, toolX: 0, toolY: -258, toolRot: 0, g1: -62, g2: 62, brow: -2, hipL: 0.34, kneeL: -0.18, hipR: -0.34, kneeR: 0.18 };

const KEYS = Object.keys(IDLE) as (keyof Pose)[];

const HIP_Y = -196;
const THIGH = 84;
const SHIN = 47;
const FOOT = 66; // ankle -> sole (boot drawn at 1.3x)
const SHOULDER: [number, number] = [62, -100]; // body-local, mirrored for arm1
const UPPER = 52;
const FORE = 46;
const TOOL_HALF = 166;

type Key = { t: number; pose: Pose; ease?: (v: number) => number };

const easeInOut = (v: number) => (v < 0.5 ? 2 * v * v : 1 - Math.pow(-2 * v + 2, 2) / 2);
const easeOutBack = (v: number) => 1 + 2.2 * Math.pow(v - 1, 3) + 1.2 * Math.pow(v - 1, 2);
const easeIn = (v: number) => v * v * v;

function lerpPose(a: Pose, b: Pose, t: number, out: Pose): Pose {
  for (const k of KEYS) out[k] = a[k] + (b[k] - a[k]) * t;
  return out;
}

function img(scene: Phaser.Scene, info: TexInfo, x = 0, y = 0): Phaser.GameObjects.Image {
  return scene.add.image(x, y, info.key, info.frame).setOrigin(info.ox, info.oy).setScale(1 / RES);
}

/**
 * BLUEFACE - claymation goblin terraformer, fully drawn in code.
 * Origin of the container = point on the ground between the boots.
 */
export class Blueface extends Phaser.GameObjects.Container {
  readonly parts: PartTextures;
  private baseScale = 1;
  private facing: BluefaceFacing = 'right';
  private action: BluefaceAction = 'idle';
  private tool: BluefaceTool = 'axe-spade';
  private walkDir = 0;
  private t = 0;
  private actT = 0;
  private walkPhase = 0;
  private blinkIn = 1.6;
  private blinkT = -1;
  private impactDone = false;
  private morphDone = false;

  private pose: Pose = { ...IDLE };

  // rig
  private shadow: Phaser.GameObjects.Graphics;
  private rig: Phaser.GameObjects.Container;
  private body_: Phaser.GameObjects.Container;
  private head: Phaser.GameObjects.Container;
  private legs: { hip: Phaser.GameObjects.Container; knee: Phaser.GameObjects.Container; boot: Phaser.GameObjects.Image; side: -1 | 1 }[] = [];
  private eyes: Phaser.GameObjects.Image[] = [];
  private brows: Phaser.GameObjects.Image[] = [];
  private grin: Phaser.GameObjects.Image;
  private shout: Phaser.GameObjects.Image;
  private eps: Phaser.GameObjects.Image[] = [];
  private arms: { upper: Phaser.GameObjects.Image; fore: Phaser.GameObjects.Image; hand: Phaser.GameObjects.Image; side: -1 | 1 }[] = [];
  private toolC: Phaser.GameObjects.Container;
  private axe: Phaser.GameObjects.Image;
  private spadeA: Phaser.GameObjects.Image;
  private glow: Phaser.GameObjects.Image;
  private bubble: Phaser.GameObjects.Container;
  private sparks?: Phaser.GameObjects.Particles.ParticleEmitter;
  private dirt?: Phaser.GameObjects.Particles.ParticleEmitter;

  constructor(scene: Phaser.Scene, x: number, y: number, scale = 1) {
    super(scene, x, y);
    this.baseScale = scale;
    const p = (this.parts = buildParts(scene));

    this.shadow = scene.add.graphics();
    this.drawShadow(0);
    this.rig = scene.add.container(0, 0);
    this.add([this.shadow, this.rig]);

    // legs (behind the tunic)
    for (const side of [-1, 1] as const) {
      const hip = scene.add.container(side * 25, HIP_Y);
      const thigh = img(scene, p.thigh).setScale(1.12 / RES, 0.9 / RES);
      const knee = scene.add.container(0, THIGH);
      const shin = img(scene, p.shin).setScale(1.12 / RES, 0.9 / RES);
      const boot = img(scene, p.boot, 0, SHIN).setScale(1.3 / RES);
      if (side > 0) boot.setFlipX(true);
      if (side > 0) boot.setOrigin(1 - p.boot.ox, p.boot.oy);
      knee.add([boot, shin]);
      hip.add([thigh, knee]);
      this.rig.add(hip);
      this.legs.push({ hip, knee, boot, side });
    }

    // body + head
    this.body_ = scene.add.container(0, -205);
    const torso = img(scene, p.torso).setScale(1.14 / RES, 1 / RES);
    this.head = scene.add.container(0, -118).setScale(1.12);
    const hornL = img(scene, p.horn, -40, -128);
    const hornR = img(scene, p.horn, 40, -128).setFlipX(true).setOrigin(1 - p.horn.ox, p.horn.oy);
    const earL = img(scene, p.ear, -44, -72).setScale(1.2 / RES);
    const earR = img(scene, p.ear, 44, -72).setFlipX(true).setOrigin(1 - p.ear.ox, p.ear.oy).setScale(1.2 / RES);
    const face = img(scene, p.face).setScale(1.1 / RES);
    const eyeL = img(scene, p.eye, -20, -66).setScale(1.12 / RES);
    const eyeR = img(scene, p.eye, 20, -66).setScale(1.12 / RES);
    const browL = img(scene, p.brow, -21, -81).setScale(1.25 / RES);
    const browR = img(scene, p.brow, 21, -81).setFlipX(true).setScale(1.25 / RES);
    this.grin = img(scene, p.grin, 0, -30);
    this.shout = img(scene, p.shout, 0, -32).setVisible(false);
    const helmet = img(scene, p.helmet);
    this.head.add([hornL, hornR, earL, earR, face, eyeL, eyeR, browL, browR, this.grin, this.shout, helmet]);
    this.eyes = [eyeL, eyeR];
    this.brows = [browL, browR];
    const epL = img(scene, p.epaulette, -64, -110).setRotation(-0.12).setScale(1.3 / RES);
    const epR = img(scene, p.epaulette, 64, -110).setFlipX(true).setRotation(0.12).setScale(1.3 / RES);
    this.eps = [epL, epR];
    this.body_.add([torso, this.head]);
    this.rig.add(this.body_);

    // arms (upper + forearm), tool, hands on top
    for (const side of [-1, 1] as const) {
      const upper = img(scene, p.upperArm).setScale(1 / RES, 1.3 / RES);
      const fore = img(scene, p.forearm).setScale(1 / RES, 1.3 / RES);
      this.arms.push({ upper, fore, hand: null as unknown as Phaser.GameObjects.Image, side });
      this.rig.add([upper, fore]);
    }
    // epaulettes sit over the shoulder joint -> on top of the sleeves
    this.rig.add([epL, epR]);
    this.toolC = scene.add.container(0, 0);
    const shaft = img(scene, p.shaft);
    this.axe = img(scene, p.axe, -TOOL_HALF + 2, 0);
    this.spadeA = img(scene, p.spade, -TOOL_HALF + 4, 0).setFlipX(true).setOrigin(1 - p.spade.ox, p.spade.oy).setScale(0).setAlpha(0);
    const spadeB = img(scene, p.spade, TOOL_HALF - 4, 0);
    this.glow = scene.add.image(-TOOL_HALF - 30, 40, p.spark).setScale(0).setAlpha(0).setBlendMode(Phaser.BlendModes.ADD);
    this.toolC.add([shaft, this.axe, this.spadeA, spadeB, this.glow]);
    this.rig.add(this.toolC);
    for (const a of this.arms) {
      a.hand = img(scene, p.hand).setScale(1.5 / RES);
      this.rig.add(a.hand);
    }

    // speech bubble
    this.bubble = this.makeBubble('Yeah! Take that!');
    this.rig.add(this.bubble);

    this.setScale(scale);
    scene.add.existing(this);
    scene.events.on(Phaser.Scenes.Events.UPDATE, this.tick, this);
    this.once(Phaser.GameObjects.Events.DESTROY, () => scene.events.off(Phaser.Scenes.Events.UPDATE, this.tick, this));

    this.sparks = scene.add.particles(0, 0, p.spark, {
      speed: { min: 60, max: 220 }, lifespan: 700, scale: { start: 1.6, end: 0 }, blendMode: 'ADD', emitting: false,
      tint: [0xffe7a0, 0xd8a8ff, 0xffb0d0, 0xffffff],
    });
    this.dirt = scene.add.particles(0, 0, p.dirt, {
      speed: { min: 120, max: 320 }, angle: { min: 200, max: 340 }, gravityY: 900, lifespan: 900,
      scale: { start: 1.2, end: 0.5 }, rotate: { min: 0, max: 360 }, emitting: false,
    });
    this.tick(0, 0);
  }

  // ---------------------------------------------------------------- public API
  idle(): this { if (this.action === 'walk' || this.action === 'idle') this.setAction('idle'); return this; }
  /** Start (or keep) walking. dir: -1 left, 1 right. Movement is done by the scene via getWalkDir(). */
  walk(dir: -1 | 1): this {
    if (this.busy()) return this;
    this.walkDir = dir;
    this.setFacing(dir < 0 ? 'left' : 'right');
    if (this.action !== 'walk') this.setAction('walk');
    return this;
  }
  dig(): this { if (!this.busy()) this.setAction('dig'); return this; }
  cheer(): this { if (!this.busy()) this.setAction('cheer'); return this; }
  /** "Yeah! Take that!" - morphs the axe head into a second iridescent spade (or back). */
  takeThat(): this { if (!this.busy()) this.setAction('takeThat'); return this; }
  morph(): this { return this.takeThat(); }

  setFacing(f: BluefaceFacing): this {
    this.facing = f;
    this.scaleX = this.baseScale * (f === 'left' ? -1 : 1);
    this.bubble.scaleX = f === 'left' ? -1 : 1;
    return this;
  }
  getFacing(): BluefaceFacing { return this.facing; }
  getAction(): BluefaceAction { return this.action; }
  getWalkDir(): number { return this.action === 'walk' ? this.walkDir : 0; }
  busy(): boolean { return this.action === 'dig' || this.action === 'cheer' || this.action === 'takeThat'; }

  getState(): BluefaceState {
    return {
      v: 1, name: 'BLUEFACE', crown: 'Я',
      position: { x: Math.round(this.x), y: Math.round(this.y) },
      facing: this.facing, action: this.action, tool: this.tool,
    };
  }
  applyState(s: BluefaceState): this {
    this.setPosition(s.position.x, s.position.y);
    this.setFacing(s.facing);
    this.setTool(s.tool);
    this.setAction('idle');
    return this;
  }
  setTool(tool: BluefaceTool): this {
    this.tool = tool;
    const ds = tool === 'double-spade';
    this.axe.setScale(ds ? 0 : 1 / RES).setAlpha(ds ? 0 : 1);
    this.spadeA.setScale(ds ? 1 / RES : 0).setAlpha(ds ? 1 : 0);
    return this;
  }

  // ---------------------------------------------------------------- internals
  private setAction(a: BluefaceAction) {
    this.action = a;
    this.actT = 0;
    this.impactDone = false;
    this.morphDone = false;
    if (a !== 'walk') this.walkDir = 0;
    if (a === 'takeThat') this.showBubble(true);
    this.emit('action', a);
  }

  private makeBubble(text: string): Phaser.GameObjects.Container {
    const s = this.scene;
    const label = s.add.text(0, 0, text, {
      fontFamily: '"Arial Black", "Helvetica Neue", Arial, sans-serif', fontSize: '30px', color: '#1c3666', fontStyle: 'bold',
      resolution: 2,
    }).setOrigin(0.5);
    const w = label.width + 44;
    const h = label.height + 26;
    const g = s.add.graphics();
    g.fillStyle(0x000000, 0.3).fillRoundedRect(-w / 2 + 4, -h / 2 + 6, w, h, 22);
    g.fillStyle(0xf6f0e4, 1).fillRoundedRect(-w / 2, -h / 2, w, h, 22);
    g.fillTriangle(-w / 2 + 40, h / 2 - 4, -w / 2 + 80, h / 2 - 4, -w / 2 + 10, h / 2 + 38);
    g.lineStyle(4, 0x1c3666, 1).strokeRoundedRect(-w / 2, -h / 2, w, h, 22);
    const c = s.add.container(150 + w / 2 - 60, -600, [g, label]);
    c.setVisible(false).setScale(0);
    return c;
  }

  private showBubble(on: boolean) {
    const sx = this.facing === 'left' ? -1 : 1;
    this.scene.tweens.killTweensOf(this.bubble);
    if (on) {
      this.bubble.setVisible(true).setScale(0.2 * sx, 0.2);
      this.scene.tweens.add({ targets: this.bubble, scaleX: sx, scaleY: 1, duration: 260, ease: 'Back.Out' });
    } else {
      this.scene.tweens.add({ targets: this.bubble, scaleX: 0, scaleY: 0, duration: 200, ease: 'Back.In', onComplete: () => this.bubble.setVisible(false) });
    }
  }

  private drawShadow(spread: number) {
    this.shadow.clear();
    this.shadow.fillStyle(0x000000, 0.18).fillEllipse(0, 2, 280 + spread, 40);
    this.shadow.fillStyle(0x000000, 0.22).fillEllipse(0, 2, 200 + spread, 24);
  }

  private keys(keys: Key[], t: number): Pose {
    let i = 0;
    while (i < keys.length - 1 && t > keys[i + 1].t) i++;
    const a = keys[i];
    const b = keys[Math.min(i + 1, keys.length - 1)];
    const span = b.t - a.t;
    const v = span <= 0 ? 1 : Phaser.Math.Clamp((t - a.t) / span, 0, 1);
    return lerpPose(a.pose, b.pose, (b.ease ?? easeInOut)(v), { ...IDLE });
  }

  private idleBase(): Pose {
    const base = this.tool === 'double-spade' ? { ...IDLE, toolRot: 0.9, toolX: -70 } : IDLE;
    return base;
  }

  private tick(_time: number, deltaMs: number) {
    const dt = Math.min(deltaMs / 1000, 0.05);
    this.t += dt;
    this.actT += dt;
    const T = this.actT;
    let tgt: Pose;
    let follow = 12;
    let mouth: 'grin' | 'shout' = 'grin';
    let jump = 0;

    switch (this.action) {
      case 'walk': {
        this.walkPhase += dt * 9.5;
        const ph = this.walkPhase;
        tgt = { ...WALK };
        tgt.hipL = -0.5 * Math.sin(ph);
        tgt.hipR = 0.5 * Math.sin(ph);
        tgt.kneeL = 0.85 * Math.max(0, Math.cos(ph));
        tgt.kneeR = 0.85 * Math.max(0, -Math.cos(ph));
        tgt.toolY += Math.sin(ph * 2) * 4;
        tgt.bodyY = -Math.abs(Math.cos(ph)) * 3;
        tgt.headRot = Math.sin(ph) * 0.04;
        follow = 18;
        break;
      }
      case 'dig': {
        const idle = this.idleBase();
        tgt = this.keys([
          { t: 0, pose: this.pose },
          { t: 0.38, pose: DIG_UP, ease: easeInOut },
          { t: 0.56, pose: DIG_DOWN, ease: easeIn },
          { t: 0.72, pose: { ...DIG_DOWN, toolRot: 1.0, toolX: -22 } },
          { t: 0.9, pose: { ...DIG_DOWN, toolRot: 0.85, toolY: -222, bodyRot: 0.05 } },
          { t: 1.35, pose: idle },
        ], T);
        follow = 30;
        if (T > 0.56 && !this.impactDone) { this.impactDone = true; this.onImpact(); }
        if (T > 1.35) this.setAction('idle');
        break;
      }
      case 'cheer': {
        const up = { ...CHEER };
        tgt = this.keys([
          { t: 0, pose: this.pose },
          { t: 0.3, pose: up, ease: easeOutBack },
          { t: 1.3, pose: up },
          { t: 1.7, pose: this.idleBase() },
        ], T);
        if (T > 0.25 && T < 1.35) {
          const j = Math.abs(Math.sin(((T - 0.25) / 0.52) * Math.PI));
          jump = j * 34;
          tgt.toolRot = -1.45 + Math.sin(T * 12) * 0.08;
          tgt.fy1 = -388 + Math.sin(T * 14) * 10;
          tgt.kneeL = -0.1 - (1 - j) * 0.3; tgt.kneeR = -tgt.kneeL;
          mouth = 'shout';
        }
        follow = 26;
        if (T > 1.7) this.setAction('idle');
        break;
      }
      case 'takeThat': {
        tgt = this.keys([
          { t: 0, pose: this.pose },
          { t: 0.3, pose: TAKE_THAT, ease: easeOutBack },
          { t: 1.25, pose: { ...TAKE_THAT, toolRot: -0.28 } },
          { t: 1.75, pose: PRESENT, ease: easeInOut },
          { t: 2.9, pose: PRESENT },
          { t: 3.3, pose: this.tool === 'double-spade' ? { ...IDLE, toolRot: 0.9, toolX: -70 } : IDLE },
        ], T);
        mouth = T < 1.6 ? 'shout' : 'grin';
        if (T > 0.3 && T < 1.25) {
          // shout shake + morph wobble on the far head
          tgt.headRot += Math.sin(T * 38) * 0.035;
          this.morphFx(T);
        }
        if (T > 0.95 && !this.morphDone) { this.morphDone = true; this.doMorph(); }
        if (T > 2.3 && this.bubble.visible && this.bubble.scaleY > 0.9) this.showBubble(false);
        follow = 26;
        if (T > 3.3) this.setAction('idle');
        break;
      }
      default: {
        tgt = { ...this.idleBase() };
        const br = Math.sin(this.t * 2.3);
        tgt.bodyY = br * 2.2;
        tgt.toolY += br * 2.2;
        tgt.toolRot += Math.sin(this.t * 1.1) * 0.02;
        tgt.headRot = Math.sin(this.t * 1.3) * 0.035;
        follow = 8;
      }
    }

    const k = 1 - Math.exp(-dt * follow);
    for (const key of KEYS) this.pose[key] += (tgt[key] - this.pose[key]) * (deltaMs === 0 ? 1 : k);

    this.grin.setVisible(mouth === 'grin');
    this.shout.setVisible(mouth === 'shout');
    // grin pulse
    const pulse = 1 + Math.max(0, Math.sin(this.t * 0.9)) * 0.05;
    this.grin.setScale((1.1 * pulse) / RES, 1.1 / RES);
    this.shout.setScale((1 + Math.sin(this.t * 30) * 0.03) / RES, 1 / RES);

    this.updateBlink(dt);
    this.applyPose(jump);
  }

  private updateBlink(dt: number) {
    if (this.blinkT < 0) {
      this.blinkIn -= dt;
      if (this.blinkIn <= 0) { this.blinkT = 0; this.blinkIn = 2.2 + Math.random() * 2.5; }
    }
    let sy = 1;
    if (this.blinkT >= 0) {
      this.blinkT += dt;
      const p = this.blinkT / 0.16;
      sy = 1 - Math.sin(Math.min(p, 1) * Math.PI) * 0.9;
      if (p >= 1) this.blinkT = -1;
    }
    for (const e of this.eyes) e.scaleY = (sy * 1.12) / RES;
  }

  private applyPose(jump: number) {
    const P = this.pose;
    const walking = this.action === 'walk';
    // legs
    const feet: number[] = [];
    this.legs.forEach((l) => {
      const hip = l.side < 0 ? P.hipL : P.hipR;
      const knee = l.side < 0 ? P.kneeL : P.kneeR;
      l.hip.rotation = hip;
      l.knee.rotation = knee;
      l.boot.rotation = -(hip + knee);
      // boots: toes outward when standing, toes forward when walking
      const toeForward = walking;
      const flip = toeForward ? true : l.side > 0;
      l.boot.setFlipX(flip);
      l.boot.setOrigin(flip ? 1 - this.parts.boot.ox : this.parts.boot.ox, this.parts.boot.oy);
      feet.push(HIP_Y + THIGH * Math.cos(hip) + SHIN * Math.cos(hip + knee) + FOOT);
    });
    const ground = Math.max(...feet);
    this.rig.y = -ground - jump;
    this.drawShadow(-jump * 1.5);
    this.shadow.alpha = 1 - jump / 90;

    // body
    this.body_.y = -205 + P.bodyY;
    this.body_.rotation = P.bodyRot;
    this.head.rotation = P.headRot;
    this.brows[0].y = -81 + P.brow;
    this.brows[1].y = -81 + P.brow;
    const cr = Math.cos(P.bodyRot);
    const sr = Math.sin(P.bodyRot);
    this.eps.forEach((e, i) => {
      const lx = (i === 0 ? -64 : 64);
      const ly = -110;
      e.setPosition(this.body_.x + lx * cr - ly * sr, this.body_.y + lx * sr + ly * cr);
      e.rotation = P.bodyRot + (i === 0 ? -0.12 : 0.12);
    });

    // tool
    this.toolC.setPosition(P.toolX, P.toolY + P.bodyY * 0.6);
    this.toolC.rotation = P.toolRot;

    // arms via 2-bone IK
    const tc = Math.cos(P.toolRot);
    const ts = Math.sin(P.toolRot);
    this.arms.forEach((a) => {
      const lx = SHOULDER[0] * a.side;
      const ly = SHOULDER[1];
      const sx = this.body_.x + lx * cr - ly * sr;
      const sy = this.body_.y + lx * sr + ly * cr;
      const g = a.side < 0 ? P.g1 : P.g2;
      let hx = this.toolC.x + g * tc;
      let hy = this.toolC.y + g * ts;
      const free = a.side < 0 ? P.free1 : 0;
      if (free > 0) { hx += (P.fx1 - hx) * free; hy += (P.fy1 - hy) * free; }
      let dx = hx - sx;
      let dy = hy - sy;
      let d = Math.hypot(dx, dy);
      const maxD = UPPER + FORE - 0.5;
      if (d > maxD) { dx *= maxD / d; dy *= maxD / d; d = maxD; }
      const base = Math.atan2(dy, dx);
      const cosA = Phaser.Math.Clamp((UPPER * UPPER + d * d - FORE * FORE) / (2 * UPPER * d), -1, 1);
      // elbow bends outward (away from body centre) and down
      const ang = Math.acos(cosA);
      // pick the elbow solution that points outward (away from the body) and down
      let best = base + ang;
      let bestScore = -Infinity;
      for (const cand of [base + ang, base - ang]) {
        const score = a.side * Math.cos(cand) + 0.6 * Math.sin(cand);
        if (score > bestScore) { bestScore = score; best = cand; }
      }
      const ua = best;
      const ex = sx + Math.cos(ua) * UPPER;
      const ey = sy + Math.sin(ua) * UPPER;
      a.upper.setPosition(sx, sy).setRotation(ua);
      const fa = Math.atan2(sy + dy - ey, sx + dx - ex);
      a.fore.setPosition(ex, ey).setRotation(fa);
      a.hand.setPosition(sx + dx, sy + dy).setRotation(P.toolRot + (free > 0.5 ? fa - P.toolRot + Math.PI / 2 : 0));
      a.hand.setFlipY(Math.sin(fa - P.toolRot) < 0);
    });
  }

  private morphFx(T: number) {
    const k = (T - 0.3) / 0.95;
    this.glow.setAlpha(Math.min(1, k * 2)).setScale((4 + Math.sin(T * 30) * 1.5) * Math.min(1, k * 2) / RES * 2);
    const head = this.tool === 'axe-spade' ? this.axe : this.spadeA;
    if (T < 0.95) head.setScale((1 + Math.sin(T * 40) * 0.06 * k) / RES, (1 - k * 0.25) / RES);
  }

  private doMorph() {
    const toSpade = this.tool === 'axe-spade';
    const from = toSpade ? this.axe : this.spadeA;
    const to = toSpade ? this.spadeA : this.axe;
    this.tool = toSpade ? 'double-spade' : 'axe-spade';
    const s = this.scene;
    s.tweens.add({ targets: from, scaleX: 0.05 / RES, scaleY: 0.05 / RES, alpha: 0, duration: 180, ease: 'Quad.In' });
    to.setScale(0.1 / RES).setAlpha(0);
    s.tweens.add({ targets: to, scaleX: 1 / RES, scaleY: 1 / RES, alpha: 1, duration: 420, delay: 120, ease: 'Back.Out' });
    s.tweens.add({ targets: this.glow, alpha: 0, scale: 0, duration: 500, delay: 250 });
    const w = this.toolWorld(-TOOL_HALF - 50, 0);
    this.sparks?.explode(28, w.x, w.y);
    this.emit('morph', this.tool);
  }

  private onImpact() {
    // where the spade tip lands in the DIG_DOWN key pose (rig-local -> world)
    const L = TOOL_HALF + 118;
    const lx = DIG_DOWN.toolX + Math.cos(DIG_DOWN.toolRot) * L;
    const tip = { x: this.x + lx * this.scaleX };
    const gy = this.y;
    this.dirt?.explode(22, tip.x, gy - 4);
    this.scene.cameras.main.shake(90, 0.004);
    this.emit('dig', { x: tip.x, y: gy });
  }

  /** tool-local point -> world coordinates */
  private toolWorld(lx: number, ly: number): Phaser.Math.Vector2 {
    const m = this.toolC.getWorldTransformMatrix();
    return new Phaser.Math.Vector2(m.getX(lx, ly), m.getY(lx, ly));
  }
}
